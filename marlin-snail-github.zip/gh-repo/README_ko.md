# 청새치 탄 달팽이 (Forge 26.x 모드 소스)

**테스트되지 않은 소스입니다.** 제작 환경에 컴파일러와 인터넷이 없어 jar 빌드/실행 확인을 못 했어요.
Forge 26.x API를 기준으로 작성했지만 아래 "오류 나기 쉬운 곳"에서 컴파일 오류가 날 수 있습니다.

## jar 만드는 법
1. https://files.minecraftforge.net 에서 최신(26.x) **Mdk** 를 받아 압축을 풉니다.
2. MDK의 `src/main/java` 안 예제(ExampleMod 등)는 지우고, 이 프로젝트의 `src/main` 을 MDK `src/main` 위에 덮어씁니다.
3. MDK의 `gradle.properties`에서 `mod_id=marlinsnail` 로 맞춥니다. (MDK의 mods.toml 템플릿이 있으면 그걸 쓰고, id/이름만 바꾸세요.)
4. JDK(MDK가 요구하는 버전)가 설치된 상태에서 `./gradlew build` 실행.
5. `build/libs/*.jar` 를 `.minecraft/mods` 에 넣으면 끝.
6. 게임에서 `/summon marlinsnail:marlin_snail` 로 소환.

## 능력 (MarlinSnailEntity.java 맨 위 상수로 조절)
- 돌진해서 찌르기: 앞으로 짧게 돌진 후 뒤로 빠짐, 데미지 18 (하트 9칸)
- 월척이다!!: 낚싯줄 파티클로 끌어당겨 낚아 올림, 데미지 10 (하트 5칸)
- 패링: 플레이어가 때리면 20% 확률로 데미지를 그대로 돌려주고 2초 스턴(이동 불가 수준 슬로우+채굴 둔화+나약함)
- 체력은 따로 안 정하셔서 120(하트 60칸)으로 해뒀어요. `createAttributes()`에서 바꾸세요.

## 모델
- 마크 기본 블록이 아니라 청새치(뾰족한 주둥이, 휜 꼬리, 지느러미)와 달팽이 인간(더듬이, 낚싯대, 둥근 껍질)을 얇은 조각과 기울인 부품으로 만든 3D 모델입니다.
- 마크 엔티티 모델은 상자 부품으로만 만들 수 있어서 사진과 똑같은 곡면은 아니고 근사 형태예요.
- 부품/색은 `tools/gen_model.py` 에서 수정 후 `python3 gen_model.py` 를 돌리면 모델 코드와 텍스처가 다시 생성됩니다.
- 더 정밀하게 하려면 Blockbench에서 모델을 만들어 Java 모델로 내보내 `MarlinSnailModel` 을 교체하세요.

## 오류 나기 쉬운 곳 (26.x에서 이름이 바뀌었을 수 있음)
- `Identifier` ↔ `ResourceLocation` (import 한 줄씩 교체)
- `FMLEnvironment.dist` (`getDist()` 형태일 수 있음)
- `XxxEvent.getBus(modBus)` 이벤트 등록 방식 (MDK의 ExampleMod 방식 그대로 따라 하기)
- `hurtServer`, `defineSynchedData`, `MobEffects.SLOWNESS/MINING_FATIGUE/WEAKNESS` 시그니처
- `pack.mcmeta` 의 `pack_format` (MDK 값으로 교체)
