package com.example.marlinsnail;

import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.Identifier;
import net.minecraft.util.Mth;

/**
 * 청새치 + 달팽이 인간 모델. (이 파일은 tools/gen_model.py 가 생성합니다. 부품은 gen_model.py 에서 수정하세요.)
 * 모델 좌표: 앞쪽 = -Z, 위쪽 = -Y, 바닥 = Y 24.
 */
public class MarlinSnailModel extends EntityModel<MarlinSnailRenderState> {
    public static final ModelLayerLocation LAYER =
            new ModelLayerLocation(Identifier.fromNamespaceAndPath(MarlinSnailMod.MODID, "marlin_snail"), "main");

    private final ModelPart marlin, tailUpper, tailLower, pectL, pectR, snail, head, armR, rod, shell;

    public MarlinSnailModel(ModelPart root) {
        super(root);
        this.marlin = root.getChild("marlin");
        this.tailUpper = marlin.getChild("tail_upper");
        this.tailLower = marlin.getChild("tail_lower");
        this.pectL = marlin.getChild("pect_l");
        this.pectR = marlin.getChild("pect_r");
        this.snail = marlin.getChild("snail");
        this.head = snail.getChild("head");
        this.armR = snail.getChild("arm_r");
        this.rod = snail.getChild("rod");
        this.shell = snail.getChild("shell");
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        PartDefinition marlin = root.addOrReplaceChild("marlin", CubeListBuilder.create(), PartPose.offset(0F, 24F, 0F));
        PartDefinition torso = marlin.addOrReplaceChild("torso", CubeListBuilder.create().texOffs(0, 0).addBox(-5F, -15F, -10F, 10F, 13F, 18F), PartPose.ZERO);
        PartDefinition nose = marlin.addOrReplaceChild("nose", CubeListBuilder.create().texOffs(0, 31).addBox(-4F, -14F, -18F, 8F, 11F, 8F), PartPose.ZERO);
        PartDefinition bill = marlin.addOrReplaceChild("bill", CubeListBuilder.create().texOffs(110, 0).addBox(-1F, -10F, -38F, 2F, 2F, 20F), PartPose.ZERO);
        PartDefinition bill_tip = marlin.addOrReplaceChild("bill_tip", CubeListBuilder.create().texOffs(212, 50).addBox(-0.5F, -9.5F, -44F, 1F, 1F, 6F), PartPose.ZERO);
        PartDefinition rear = marlin.addOrReplaceChild("rear", CubeListBuilder.create().texOffs(52, 31).addBox(-4F, -14F, 8F, 8F, 10F, 8F), PartPose.ZERO);
        PartDefinition peduncle = marlin.addOrReplaceChild("peduncle", CubeListBuilder.create().texOffs(56, 50).addBox(-2F, -12F, 16F, 4F, 7F, 6F), PartPose.ZERO);
        PartDefinition tail_upper = marlin.addOrReplaceChild("tail_upper", CubeListBuilder.create().texOffs(84, 31).addBox(-0.5F, -11F, -1F, 1F, 11F, 6F), PartPose.offsetAndRotation(0F, -9F, 21F, -0.55F, 0F, 0F));
        PartDefinition tail_lower = marlin.addOrReplaceChild("tail_lower", CubeListBuilder.create().texOffs(98, 31).addBox(-0.5F, 0F, -1F, 1F, 11F, 6F), PartPose.offsetAndRotation(0F, -8F, 21F, 0.55F, 0F, 0F));
        PartDefinition dorsal = marlin.addOrReplaceChild("dorsal", CubeListBuilder.create().texOffs(32, 31).addBox(-0.5F, -10F, 0F, 1F, 10F, 9F), PartPose.offsetAndRotation(0F, -13F, 9F, -0.25F, 0F, 0F));
        PartDefinition pect_r = marlin.addOrReplaceChild("pect_r", CubeListBuilder.create().texOffs(226, 50).addBox(0F, 0F, 0F, 7F, 1F, 5F), PartPose.offsetAndRotation(5F, -5F, -6F, 0.3F, 0F, 0.55F));
        PartDefinition pect_l = marlin.addOrReplaceChild("pect_l", CubeListBuilder.create().texOffs(0, 64).addBox(-7F, 0F, 0F, 7F, 1F, 5F), PartPose.offsetAndRotation(-5F, -5F, -6F, 0.3F, 0F, -0.55F));
        PartDefinition eye_r = marlin.addOrReplaceChild("eye_r", CubeListBuilder.create().texOffs(24, 64).addBox(4F, -12F, -16F, 1F, 3F, 3F), PartPose.ZERO);
        PartDefinition eye_l = marlin.addOrReplaceChild("eye_l", CubeListBuilder.create().texOffs(32, 64).addBox(-5F, -12F, -16F, 1F, 3F, 3F), PartPose.ZERO);
        PartDefinition snail = marlin.addOrReplaceChild("snail", CubeListBuilder.create(), PartPose.offset(0F, -15F, -3F));
        PartDefinition hips = snail.addOrReplaceChild("hips", CubeListBuilder.create().texOffs(184, 50).addBox(-5F, -2F, -2F, 10F, 3F, 4F), PartPose.ZERO);
        PartDefinition torso_s = snail.addOrReplaceChild("torso_s", CubeListBuilder.create().texOffs(0, 50).addBox(-4F, -12F, -2F, 8F, 10F, 4F), PartPose.ZERO);
        PartDefinition head = snail.addOrReplaceChild("head", CubeListBuilder.create().texOffs(148, 31).addBox(-4F, -8F, -4F, 8F, 8F, 8F), PartPose.offset(0F, -12F, 0F));
        PartDefinition antenna = head.addOrReplaceChild("antenna", CubeListBuilder.create().texOffs(160, 50).addBox(-1F, -15F, -1F, 2F, 7F, 2F), PartPose.ZERO);
        PartDefinition bulb = head.addOrReplaceChild("bulb", CubeListBuilder.create().texOffs(168, 50).addBox(-2F, -19F, -2F, 4F, 4F, 4F), PartPose.ZERO);
        PartDefinition arm_r = snail.addOrReplaceChild("arm_r", CubeListBuilder.create().texOffs(76, 50).addBox(-1F, -1F, -1F, 3F, 9F, 3F), PartPose.offsetAndRotation(5F, -11F, 0F, -1F, 0F, 0F));
        PartDefinition arm_l = snail.addOrReplaceChild("arm_l", CubeListBuilder.create().texOffs(88, 50).addBox(-2F, -1F, -1F, 3F, 9F, 3F), PartPose.offsetAndRotation(-5F, -11F, 0F, -0.3F, 0F, 0F));
        PartDefinition leg_r = snail.addOrReplaceChild("leg_r", CubeListBuilder.create().texOffs(24, 50).addBox(-2F, 0F, -2F, 4F, 10F, 4F), PartPose.offsetAndRotation(4F, 0F, 0F, 0F, 0F, -0.45F));
        PartDefinition leg_l = snail.addOrReplaceChild("leg_l", CubeListBuilder.create().texOffs(40, 50).addBox(-2F, 0F, -2F, 4F, 10F, 4F), PartPose.offsetAndRotation(-4F, 0F, 0F, 0F, 0F, 0.45F));
        PartDefinition rod = snail.addOrReplaceChild("rod", CubeListBuilder.create().texOffs(56, 0).addBox(0F, 0F, -26F, 1F, 1F, 26F), PartPose.offsetAndRotation(6F, -8F, -3F, -0.6F, 0F, 0F));
        PartDefinition shell = snail.addOrReplaceChild("shell", CubeListBuilder.create(), PartPose.offset(0F, -9F, 7F));
        PartDefinition shell_o1 = shell.addOrReplaceChild("shell_o1", CubeListBuilder.create().texOffs(154, 0).addBox(-3F, -4F, -7F, 6F, 8F, 14F), PartPose.ZERO);
        PartDefinition shell_o2 = shell.addOrReplaceChild("shell_o2", CubeListBuilder.create().texOffs(194, 0).addBox(-3F, -7F, -4F, 6F, 14F, 8F), PartPose.ZERO);
        PartDefinition shell_o3 = shell.addOrReplaceChild("shell_o3", CubeListBuilder.create().texOffs(222, 0).addBox(-3F, -5F, -5F, 6F, 10F, 10F), PartPose.ZERO);
        PartDefinition shell_m1 = shell.addOrReplaceChild("shell_m1", CubeListBuilder.create().texOffs(112, 31).addBox(-4F, -3F, -5F, 8F, 6F, 10F), PartPose.ZERO);
        PartDefinition shell_m2 = shell.addOrReplaceChild("shell_m2", CubeListBuilder.create().texOffs(180, 31).addBox(-4F, -5F, -3F, 8F, 10F, 6F), PartPose.ZERO);
        PartDefinition shell_m3 = shell.addOrReplaceChild("shell_m3", CubeListBuilder.create().texOffs(208, 31).addBox(-4F, -3.5F, -3.5F, 8F, 7F, 7F), PartPose.ZERO);
        PartDefinition shell_c1 = shell.addOrReplaceChild("shell_c1", CubeListBuilder.create().texOffs(100, 50).addBox(-5F, -2F, -3F, 10F, 4F, 6F), PartPose.ZERO);
        PartDefinition shell_c2 = shell.addOrReplaceChild("shell_c2", CubeListBuilder.create().texOffs(132, 50).addBox(-5F, -3F, -2F, 10F, 6F, 4F), PartPose.ZERO);
        return LayerDefinition.create(mesh, 256, 256);
    }

    @Override
    public void setupAnim(MarlinSnailRenderState s) {
        super.setupAnim(s); // 매 프레임 기본 자세로 리셋됨
        float t = s.ageInTicks;
        float deg = (float) Math.PI / 180F;

        // 꼬리/지느러미 헤엄 움직임
        float swish = Mth.sin(t * 0.18F + s.walkAnimationPos) * (0.25F + s.walkAnimationSpeed * 0.5F);
        tailUpper.yRot += swish;
        tailLower.yRot += swish;
        pectR.zRot += Mth.sin(t * 0.15F) * 0.15F;
        pectL.zRot -= Mth.sin(t * 0.15F) * 0.15F;
        marlin.zRot += Mth.sin(t * 0.08F) * 0.02F;

        // 달팽이 인간이 주변을 둘러봄
        head.yRot += Mth.clamp(s.yRot, -50F, 50F) * deg * 0.7F;
        head.xRot += Mth.clamp(s.xRot, -30F, 30F) * deg * 0.7F;
        shell.xRot += Mth.sin(t * 0.12F) * 0.03F;

        switch (s.abilityState) {
            case 1 -> { // 돌진 준비: 뒤로 살짝 빼며 힘 모으기
                marlin.z += 5F;
                marlin.xRot += 0.1F;
            }
            case 2 -> { // 돌진해서 찌르기
                marlin.z -= 7F;
                marlin.xRot -= 0.12F;
                shell.xRot += 0.15F;
            }
            case 3 -> marlin.z += 3F; // 빠지기
            case 4 -> { // 낚싯대 휘두르기 (월척이다!!)
                float sw = -0.9F + Mth.sin(t * 0.9F) * 0.25F;
                armR.xRot += sw;
                rod.xRot += sw * 0.6F;
            }
            case 5 -> { // 낚아 올리는 중
                float sw = -0.4F + Mth.sin(t * 1.6F) * 0.35F;
                armR.xRot += sw;
                rod.xRot += sw * 0.6F;
            }
            default -> { }
        }
    }
}
