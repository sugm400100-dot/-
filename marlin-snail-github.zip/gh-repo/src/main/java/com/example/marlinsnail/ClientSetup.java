package com.example.marlinsnail;

import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.eventbus.api.bus.BusGroup;

final class ClientSetup {
    private ClientSetup() {}

    static void init(BusGroup modBus) {
        EntityRenderersEvent.RegisterLayerDefinitions.getBus(modBus).addListener(ClientSetup::layers);
        EntityRenderersEvent.RegisterRenderers.getBus(modBus).addListener(ClientSetup::renderers);
    }

    private static void layers(EntityRenderersEvent.RegisterLayerDefinitions event) {
        event.registerLayerDefinition(MarlinSnailModel.LAYER, MarlinSnailModel::createBodyLayer);
    }

    private static void renderers(EntityRenderersEvent.RegisterRenderers event) {
        event.registerEntityRenderer(MarlinSnailMod.MARLIN_SNAIL.get(), MarlinSnailRenderer::new);
    }
}
