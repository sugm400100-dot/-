package com.example.marlinsnail;

import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.Identifier;

public class MarlinSnailRenderer extends MobRenderer<MarlinSnailEntity, MarlinSnailRenderState, MarlinSnailModel> {
    private static final Identifier TEXTURE =
            Identifier.fromNamespaceAndPath(MarlinSnailMod.MODID, "textures/entity/marlin_snail.png");

    public MarlinSnailRenderer(EntityRendererProvider.Context ctx) {
        super(ctx, new MarlinSnailModel(ctx.bakeLayer(MarlinSnailModel.LAYER)), 1.1F);
    }

    @Override
    public MarlinSnailRenderState createRenderState() {
        return new MarlinSnailRenderState();
    }

    @Override
    public void extractRenderState(MarlinSnailEntity entity, MarlinSnailRenderState state, float partialTick) {
        super.extractRenderState(entity, state, partialTick);
        state.abilityState = entity.getAbilityState();
    }

    @Override
    public Identifier getTextureLocation(MarlinSnailRenderState state) {
        return TEXTURE;
    }
}
