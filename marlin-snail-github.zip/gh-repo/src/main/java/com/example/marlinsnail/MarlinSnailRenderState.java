package com.example.marlinsnail;

import net.minecraft.client.renderer.entity.state.LivingEntityRenderState;

public class MarlinSnailRenderState extends LivingEntityRenderState {
    /** 0=대기 1=돌진준비 2=돌진 3=빠지기 4=낚싯대 던지기 5=낚아 올리기 */
    public int abilityState;
}
