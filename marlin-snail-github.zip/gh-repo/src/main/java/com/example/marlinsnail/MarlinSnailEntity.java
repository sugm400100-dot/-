package com.example.marlinsnail;

import java.util.EnumSet;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.util.Mth;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.MoveTowardsTargetGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

/**
 * 청새치 탄 달팽이.
 *  1) 돌진해서 찌르기 : 청새치가 살짝 앞으로 돌진했다가 빠짐 (하트 9칸 = 18)
 *  2) 월척이다!!      : 달팽이가 낚싯대로 플레이어를 낚아 올림 (하트 5칸 = 10)
 *  3) 패링            : 맞으면 20% 확률로 데미지를 돌려주고 플레이어를 2초 스턴
 */
public class MarlinSnailEntity extends Monster {
    public static final int IDLE = 0, WINDUP = 1, DASH = 2, RETREAT = 3, CAST = 4, REEL = 5;

    private static final EntityDataAccessor<Integer> STATE =
            SynchedEntityData.defineId(MarlinSnailEntity.class, EntityDataSerializers.INT);

    private static final float STAB_DAMAGE = 18.0F; // 하트 9개
    private static final float FISH_DAMAGE = 10.0F; // 하트 5개
    private static final float PARRY_CHANCE = 0.20F;
    private static final int STUN_TICKS = 40;       // 2초

    private int chargeCooldown = 40;
    private int fishCooldown = 80;

    public MarlinSnailEntity(EntityType<? extends MarlinSnailEntity> type, Level level) {
        super(type, level);
        this.xpReward = 40;
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, 120.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.28D)
                .add(Attributes.FOLLOW_RANGE, 32.0D)
                .add(Attributes.KNOCKBACK_RESISTANCE, 0.6D)
                .add(Attributes.ATTACK_DAMAGE, 4.0D);
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {
        super.defineSynchedData(builder);
        builder.define(STATE, IDLE);
    }

    public int getAbilityState() {
        return this.entityData.get(STATE);
    }

    private void setAbilityState(int s) {
        this.entityData.set(STATE, s);
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(1, new AbilityGoal());
        this.goalSelector.addGoal(2, new MoveTowardsTargetGoal(this, 1.0D, 24.0F));
        this.goalSelector.addGoal(3, new WaterAvoidingRandomStrollGoal(this, 0.8D));
        this.goalSelector.addGoal(4, new LookAtPlayerGoal(this, Player.class, 16.0F));
        this.goalSelector.addGoal(5, new RandomLookAroundGoal(this));
        this.targetSelector.addGoal(1, new HurtByTargetGoal(this));
        this.targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Player.class, true));
    }

    @Override
    public void tick() {
        super.tick();
        if (this.level() instanceof ServerLevel) {
            if (chargeCooldown > 0) chargeCooldown--;
            if (fishCooldown > 0) fishCooldown--;
        }
    }

    // ---------------- 3) 패링 ----------------
    @Override
    public boolean hurtServer(ServerLevel level, DamageSource source, float amount) {
        Entity attacker = source.getEntity();
        if (attacker instanceof Player player
                && !source.is(DamageTypeTags.BYPASSES_INVULNERABILITY)
                && this.random.nextFloat() < PARRY_CHANCE) {
            // 데미지는 받지 않고 그대로 돌려줌
            player.hurtServer(level, this.damageSources().mobAttack(this), amount);
            stun(player);
            level.sendParticles(ParticleTypes.CRIT, getX(), getY() + 1.8, getZ(), 24, 0.6, 0.6, 0.6, 0.3);
            this.playSound(SoundEvents.SHIELD_BLOCK, 1.2F, 0.9F);
            return false;
        }
        return super.hurtServer(level, source, amount);
    }

    private void stun(Player p) {
        p.addEffect(new MobEffectInstance(MobEffects.SLOWNESS, STUN_TICKS, 9, false, true));
        p.addEffect(new MobEffectInstance(MobEffects.MINING_FATIGUE, STUN_TICKS, 4, false, false));
        p.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, STUN_TICKS, 9, false, false));
        p.setDeltaMovement(0, Math.min(0, p.getDeltaMovement().y), 0);
        p.hurtMarked = true;
        p.displayClientMessage(Component.literal("패링! 2초 스턴"), true);
    }

    // ---------------- 능력 AI ----------------
    private class AbilityGoal extends Goal {
        private int ticks;
        private Vec3 dashDir = Vec3.ZERO;
        private boolean dashHit;
        private LivingEntity hooked;

        AbilityGoal() {
            this.setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK));
        }

        @Override
        public boolean canUse() {
            LivingEntity t = getTarget();
            if (t == null || !t.isAlive()) return false;
            double d = distanceToSqr(t);
            return (chargeCooldown <= 0 && d <= 100.0D)
                    || (fishCooldown <= 0 && d <= 324.0D && hasLineOfSight(t));
        }

        @Override
        public boolean canContinueToUse() {
            return getAbilityState() != IDLE;
        }

        @Override
        public boolean requiresUpdateEveryTick() {
            return true;
        }

        @Override
        public void start() {
            LivingEntity t = getTarget();
            ticks = 0;
            if (t != null && chargeCooldown <= 0 && distanceToSqr(t) <= 100.0D) {
                chargeCooldown = 100;
                setAbilityState(WINDUP);
            } else {
                fishCooldown = 160;
                setAbilityState(CAST);
                playSound(SoundEvents.FISHING_BOBBER_THROW, 1.0F, 0.8F);
            }
        }

        @Override
        public void stop() {
            setAbilityState(IDLE);
            hooked = null;
        }

        @Override
        public void tick() {
            if (!(level() instanceof ServerLevel sl)) return;
            LivingEntity t = getTarget();
            ticks++;
            getNavigation().stop();

            switch (getAbilityState()) {
                case WINDUP -> {
                    if (t != null) faceTarget(t);
                    if (ticks >= 14) {
                        Vec3 dir = t != null
                                ? new Vec3(t.getX() - getX(), 0, t.getZ() - getZ())
                                : Vec3.directionFromRotation(0, getYRot());
                        dashDir = dir.lengthSqr() > 1.0E-4 ? dir.normalize() : new Vec3(0, 0, 1);
                        dashHit = false;
                        ticks = 0;
                        setAbilityState(DASH);
                        playSound(SoundEvents.TRIDENT_THROW, 1.3F, 0.7F);
                    }
                }
                case DASH -> {
                    setDeltaMovement(dashDir.x * 1.1, getDeltaMovement().y, dashDir.z * 1.1);
                    hasImpulse = true;
                    if (!dashHit) dashHit = stab(sl);
                    if (ticks >= 7) {
                        ticks = 0;
                        setAbilityState(RETREAT);
                    }
                }
                case RETREAT -> {
                    setDeltaMovement(-dashDir.x * 0.45, getDeltaMovement().y, -dashDir.z * 0.45);
                    hasImpulse = true;
                    if (ticks >= 10) setAbilityState(IDLE);
                }
                case CAST -> {
                    if (t != null) faceTarget(t);
                    if (ticks >= 20) {
                        if (t != null && t.isAlive() && hasLineOfSight(t)) {
                            hooked = t;
                            ticks = 0;
                            setAbilityState(REEL);
                            playSound(SoundEvents.FISHING_BOBBER_SPLASH, 1.0F, 1.0F);
                        } else {
                            setAbilityState(IDLE);
                        }
                    }
                }
                case REEL -> reel(sl);
                default -> setAbilityState(IDLE);
            }
        }

        private void faceTarget(LivingEntity t) {
            getLookControl().setLookAt(t, 60.0F, 60.0F);
            float yaw = (float) (Mth.atan2(t.getZ() - getZ(), t.getX() - getX()) * 180.0D / Math.PI) - 90.0F;
            setYRot(yaw);
            yBodyRot = yaw;
            yHeadRot = yaw;
        }

        /** 1) 돌진해서 찌르기: 청새치 주둥이에 닿은 플레이어에게 하트 9칸 */
        private boolean stab(ServerLevel sl) {
            AABB box = getBoundingBox().expandTowards(dashDir.scale(3.0)).inflate(1.0, 0.3, 1.0);
            boolean hit = false;
            for (Player p : sl.getEntitiesOfClass(Player.class, box)) {
                if (p.isSpectator()) continue;
                p.hurtServer(sl, damageSources().mobAttack(MarlinSnailEntity.this), STAB_DAMAGE);
                p.setDeltaMovement(p.getDeltaMovement().add(dashDir.x * 1.3, 0.45, dashDir.z * 1.3));
                p.hurtMarked = true;
                hit = true;
            }
            if (hit) {
                playSound(SoundEvents.TRIDENT_HIT, 1.2F, 0.8F);
            }
            return hit;
        }

        /** 2) 월척이다!!: 낚싯줄로 끌어당겨서 낚아 올리고 하트 5칸 */
        private void reel(ServerLevel sl) {
            if (hooked == null || !hooked.isAlive() || ticks > 25) {
                hooked = null;
                setAbilityState(IDLE);
                return;
            }
            drawLine(sl, rodTip(), hooked.getEyePosition());
            Vec3 pull = position().add(0, 2.2, 0).subtract(hooked.position());
            if (pull.length() < 2.0 || ticks >= 14) {
                hooked.hurtServer(sl, damageSources().mobAttack(MarlinSnailEntity.this), FISH_DAMAGE);
                hooked.setDeltaMovement(0, 0.8, 0);
                hooked.hurtMarked = true;
                playSound(SoundEvents.FISHING_BOBBER_RETRIEVE, 1.2F, 0.9F);
                hooked = null;
                setAbilityState(IDLE);
                return;
            }
            hooked.setDeltaMovement(pull.normalize().scale(0.85));
            hooked.hurtMarked = true;
        }

        private Vec3 rodTip() {
            return position().add(0, 2.4, 0).add(Vec3.directionFromRotation(0, yBodyRot).scale(1.7));
        }

        private void drawLine(ServerLevel sl, Vec3 a, Vec3 b) {
            for (int i = 0; i <= 12; i++) {
                Vec3 p = a.lerp(b, i / 12.0);
                sl.sendParticles(ParticleTypes.END_ROD, p.x, p.y, p.z, 1, 0, 0, 0, 0);
            }
        }
    }

    // ---------------- 소리 ----------------
    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return SoundEvents.DOLPHIN_HURT;
    }

    @Override
    protected SoundEvent getDeathSound() {
        return SoundEvents.DOLPHIN_DEATH;
    }
}
