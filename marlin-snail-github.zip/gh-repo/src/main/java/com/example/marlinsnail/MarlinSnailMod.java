package com.example.marlinsnail;

import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.eventbus.api.bus.BusGroup;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.fml.loading.FMLEnvironment;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.RegistryObject;

@Mod(MarlinSnailMod.MODID)
public class MarlinSnailMod {
    public static final String MODID = "marlinsnail";

    public static final DeferredRegister<EntityType<?>> ENTITIES = DeferredRegister.create(Registries.ENTITY_TYPE, MODID);

    public static final RegistryObject<EntityType<MarlinSnailEntity>> MARLIN_SNAIL = ENTITIES.register("marlin_snail",
            () -> EntityType.Builder.of(MarlinSnailEntity::new, MobCategory.MONSTER)
                    .sized(1.6F, 2.6F)
                    .clientTrackingRange(10)
                    .build(ResourceKey.create(Registries.ENTITY_TYPE, Identifier.fromNamespaceAndPath(MODID, "marlin_snail"))));

    public MarlinSnailMod(FMLJavaModLoadingContext context) {
        BusGroup modBus = context.getModBusGroup();
        ENTITIES.register(modBus);
        EntityAttributeCreationEvent.getBus(modBus).addListener(MarlinSnailMod::onAttributes);
        if (FMLEnvironment.dist == Dist.CLIENT) {
            ClientSetup.init(modBus);
        }
    }

    private static void onAttributes(EntityAttributeCreationEvent event) {
        event.put(MARLIN_SNAIL.get(), MarlinSnailEntity.createAttributes().build());
    }
}
