package com.example.marlinsnail;

import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.Identifier;
import net.minecraft.util.Mth;

/**
 * 청새치 + 달팽이 인간 모델. (이 파일은 tools/gen_model.py 가 생성합니다. 부품은 gen_model.py 에서 수정하세요.)
 * 모델 좌표: 앞쪽 = -Z, 위쪽 = -Y, 바닥 = Y 24.
 */
public class MarlinSnailModel extends EntityModel<MarlinSnailRenderState> {
    public static final ModelLayerLocation LAYER =
            new ModelLayerLocation(Identifier.fromNamespaceAndPath(MarlinSnailMod.MODID, "marlin_snail"), "main");

    private final ModelPart marlin, tailUpper, tailLower, pectL, pectR, snail, head, armR, rod, shell;

    public MarlinSnailModel(ModelPart root) {
        super(root);
        this.marlin = root.getChild("marlin");
        this.tailUpper = marlin.getChild("tail_upper");
        this.tailLower = marlin.getChild("tail_lower");
        this.pectL = marlin.getChild("pect_l");
        this.pectR = marlin.getChild("pect_r");
        this.snail = marlin.getChild("snail");
        this.head = snail.getChild("head");
        this.armR = snail.getChild("arm_r");
        this.rod = snail.getChild("rod");
        this.shell = snail.getChild("shell");
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
//LAYER//
        return LayerDefinition.create(mesh, //SIZE//, //SIZE//);
    }

    @Override
    public void setupAnim(MarlinSnailRenderState s) {
        super.setupAnim(s); // 매 프레임 기본 자세로 리셋됨
        float t = s.ageInTicks;
        float deg = (float) Math.PI / 180F;

        // 꼬리/지느러미 헤엄 움직임
        float swish = Mth.sin(t * 0.18F + s.walkAnimationPos) * (0.25F + s.walkAnimationSpeed * 0.5F);
        tailUpper.yRot += swish;
        tailLower.yRot += swish;
        pectR.zRot += Mth.sin(t * 0.15F) * 0.15F;
        pectL.zRot -= Mth.sin(t * 0.15F) * 0.15F;
        marlin.zRot += Mth.sin(t * 0.08F) * 0.02F;

        // 달팽이 인간이 주변을 둘러봄
        head.yRot += Mth.clamp(s.yRot, -50F, 50F) * deg * 0.7F;
        head.xRot += Mth.clamp(s.xRot, -30F, 30F) * deg * 0.7F;
        shell.xRot += Mth.sin(t * 0.12F) * 0.03F;

        switch (s.abilityState) {
            case 1 -> { // 돌진 준비: 뒤로 살짝 빼며 힘 모으기
                marlin.z += 5F;
                marlin.xRot += 0.1F;
            }
            case 2 -> { // 돌진해서 찌르기
                marlin.z -= 7F;
                marlin.xRot -= 0.12F;
                shell.xRot += 0.15F;
            }
            case 3 -> marlin.z += 3F; // 빠지기
            case 4 -> { // 낚싯대 휘두르기 (월척이다!!)
                float sw = -0.9F + Mth.sin(t * 0.9F) * 0.25F;
                armR.xRot += sw;
                rod.xRot += sw * 0.6F;
            }
            case 5 -> { // 낚아 올리는 중
                float sw = -0.4F + Mth.sin(t * 1.6F) * 0.35F;
                armR.xRot += sw;
                rod.xRot += sw * 0.6F;
            }
            default -> { }
        }
    }
}
