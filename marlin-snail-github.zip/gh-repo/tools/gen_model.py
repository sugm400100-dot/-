import os, random, struct, zlib

BASE = "/home/claude/marlin-snail-forge"
JAVA = f"{BASE}/src/main/java/com/example/marlinsnail"
TEX = f"{BASE}/src/main/resources/assets/marlinsnail/textures/entity"
os.makedirs(JAVA, exist_ok=True)
os.makedirs(TEX, exist_ok=True)
SIZE = 256
rnd = random.Random(7)

NAVY = (24, 52, 128); BLUE_D = (34, 78, 178); BLUE = (58, 118, 222); WHITE = (232, 240, 248)
SKIN = (224, 204, 164); SHIRT = (238, 242, 246); SPECK = (60, 64, 76)
PANTS = (216, 216, 152); PANTS_D = (186, 186, 120)
ROD = (112, 74, 42); BLACK = (14, 14, 22)
SH1 = (118, 76, 60); SH2 = (160, 112, 92); SH3 = (198, 146, 122)
ANT = (214, 176, 132); ANT_L = (232, 200, 160)

parts = []


def part(name, parent, box=None, pose=(0, 0, 0, 0, 0, 0), top=None, side=None, bot=None, paint=None):
    parts.append(dict(name=name, parent=parent, box=box, pose=pose, top=top, side=side, bot=bot, paint=paint))


buf = bytearray(SIZE * SIZE * 4)


def px(x, y, col):
    if 0 <= x < SIZE and 0 <= y < SIZE:
        i = (y * SIZE + x) * 4
        buf[i:i + 4] = bytes((col[0], col[1], col[2], 255))


def fill(x, y, w, h, col):
    for yy in range(y, y + h):
        for xx in range(x, x + w):
            px(xx, yy, col)


def grad(x, y, w, h, side):
    if isinstance(side[0], tuple):
        a, b = side
        for yy in range(h):
            t = yy / max(1, h - 1)
            col = tuple(int(a[k] + (b[k] - a[k]) * t) for k in range(3))
            for xx in range(w):
                px(x + xx, y + yy, col)
    else:
        fill(x, y, w, h, side)


def shirt_paint(u, v, w, h, d):
    for fx in (u + d, u + 2 * d + w):
        for yy in range(h):
            for xx in range(w):
                if rnd.random() < 0.13:
                    px(fx + xx, v + d + yy, SPECK)


def face_paint(u, v, w, h, d):
    fx, fy = u + d, v + d
    for (ex, ey) in ((2, 3), (2, 4), (5, 3), (5, 4)):
        px(fx + ex, fy + ey, BLACK)
    for (mx, my) in ((2, 5), (3, 6), (4, 6), (5, 5)):
        px(fx + mx, fy + my, (120, 70, 60))


G = (BLUE, WHITE)
# ---------------- marlin ----------------
part("marlin", "root", pose=(0, 24, 0, 0, 0, 0))
part("torso", "marlin", (-5, -15, -10, 10, 13, 18), top=NAVY, side=G, bot=WHITE)
part("nose", "marlin", (-4, -14, -18, 8, 11, 8), top=NAVY, side=G, bot=WHITE)
part("bill", "marlin", (-1, -10, -38, 2, 2, 20), top=NAVY, side=(NAVY, BLUE_D), bot=BLUE_D)
part("bill_tip", "marlin", (-0.5, -9.5, -44, 1, 1, 6), top=NAVY, side=NAVY, bot=NAVY)
part("rear", "marlin", (-4, -14, 8, 8, 10, 8), top=NAVY, side=G, bot=WHITE)
part("peduncle", "marlin", (-2, -12, 16, 4, 7, 6), top=NAVY, side=(BLUE_D, BLUE), bot=BLUE)
part("tail_upper", "marlin", (-0.5, -11, -1, 1, 11, 6), pose=(0, -9, 21, -0.55, 0, 0), top=NAVY, side=(NAVY, BLUE_D), bot=NAVY)
part("tail_lower", "marlin", (-0.5, 0, -1, 1, 11, 6), pose=(0, -8, 21, 0.55, 0, 0), top=NAVY, side=(BLUE_D, NAVY), bot=NAVY)
part("dorsal", "marlin", (-0.5, -10, 0, 1, 10, 9), pose=(0, -13, 9, -0.25, 0, 0), top=NAVY, side=(NAVY, BLUE_D), bot=BLUE_D)
part("pect_r", "marlin", (0, 0, 0, 7, 1, 5), pose=(5, -5, -6, 0.3, 0, 0.55), top=BLUE_D, side=BLUE_D, bot=BLUE_D)
part("pect_l", "marlin", (-7, 0, 0, 7, 1, 5), pose=(-5, -5, -6, 0.3, 0, -0.55), top=BLUE_D, side=BLUE_D, bot=BLUE_D)
part("eye_r", "marlin", (4, -12, -16, 1, 3, 3), top=BLACK, side=BLACK, bot=BLACK)
part("eye_l", "marlin", (-5, -12, -16, 1, 3, 3), top=BLACK, side=BLACK, bot=BLACK)
# ---------------- snail rider ----------------
part("snail", "marlin", pose=(0, -15, -3, 0, 0, 0))
part("hips", "snail", (-5, -2, -2, 10, 3, 4), top=PANTS, side=PANTS, bot=PANTS_D)
part("torso_s", "snail", (-4, -12, -2, 8, 10, 4), top=SHIRT, side=SHIRT, bot=PANTS, paint=shirt_paint)
part("head", "snail", (-4, -8, -4, 8, 8, 8), pose=(0, -12, 0, 0, 0, 0), top=SKIN, side=SKIN, bot=SKIN, paint=face_paint)
part("antenna", "head", (-1, -15, -1, 2, 7, 2), top=ANT, side=ANT, bot=ANT)
part("bulb", "head", (-2, -19, -2, 4, 4, 4), top=ANT_L, side=ANT, bot=ANT)
part("arm_r", "snail", (-1, -1, -1, 3, 9, 3), pose=(5, -11, 0, -1.0, 0, 0), top=SHIRT, side=(SHIRT, SKIN), bot=SKIN)
part("arm_l", "snail", (-2, -1, -1, 3, 9, 3), pose=(-5, -11, 0, -0.3, 0, 0), top=SHIRT, side=(SHIRT, SKIN), bot=SKIN)
part("leg_r", "snail", (-2, 0, -2, 4, 10, 4), pose=(4, 0, 0, 0, 0, -0.45), top=PANTS, side=(PANTS, PANTS_D), bot=PANTS_D)
part("leg_l", "snail", (-2, 0, -2, 4, 10, 4), pose=(-4, 0, 0, 0, 0, 0.45), top=PANTS, side=(PANTS, PANTS_D), bot=PANTS_D)
part("rod", "snail", (0, 0, -26, 1, 1, 26), pose=(6, -8, -3, -0.6, 0, 0), top=ROD, side=ROD, bot=ROD)
# shell: concentric stepped discs (outer dark -> inner light)
part("shell", "snail", pose=(0, -9, 7, 0, 0, 0))
part("shell_o1", "shell", (-3, -4, -7, 6, 8, 14), top=SH1, side=SH1, bot=SH1)
part("shell_o2", "shell", (-3, -7, -4, 6, 14, 8), top=SH1, side=SH1, bot=SH1)
part("shell_o3", "shell", (-3, -5, -5, 6, 10, 10), top=SH1, side=SH1, bot=SH1)
part("shell_m1", "shell", (-4, -3, -5, 8, 6, 10), top=SH2, side=SH2, bot=SH2)
part("shell_m2", "shell", (-4, -5, -3, 8, 10, 6), top=SH2, side=SH2, bot=SH2)
part("shell_m3", "shell", (-4, -3.5, -3.5, 8, 7, 7), top=SH2, side=SH2, bot=SH2)
part("shell_c1", "shell", (-5, -2, -3, 10, 4, 6), top=SH3, side=SH3, bot=SH3)
part("shell_c2", "shell", (-5, -3, -2, 10, 6, 4), top=SH3, side=SH3, bot=SH3)

# ---------------- pack UVs ----------------
boxed = [p for p in parts if p["box"]]
for p in boxed:
    w, h, d = p["box"][3:]
    p["W"], p["H"] = 2 * (d + w), d + h
x = y = rowh = 0
for p in sorted(boxed, key=lambda q: (-q["H"], -q["W"])):
    if x + p["W"] > SIZE:
        x = 0; y += rowh; rowh = 0
    assert y + p["H"] <= SIZE, "atlas full"
    p["uv"] = (x, y)
    x += p["W"]; rowh = max(rowh, p["H"])

for p in boxed:
    u, v = p["uv"]
    _, _, _, w, h, d = p["box"]
    side = p["side"]
    fill(u + d, v, w, d, p["top"])
    fill(u + d + w, v, w, d, p["bot"])
    for fx, fw in ((u, d), (u + d, w), (u + d + w, d), (u + 2 * d + w, w)):
        grad(fx, v + d, fw, h, side)
    if p["paint"]:
        p["paint"](u, v, w, h, d)


def write_png(path, w, h, data):
    raw = b"".join(b"\x00" + bytes(data[r * w * 4:(r + 1) * w * 4]) for r in range(h))

    def chunk(t, dat):
        return struct.pack(">I", len(dat)) + t + dat + struct.pack(">I", zlib.crc32(t + dat) & 0xffffffff)
    png = (b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", struct.pack(">IIBBBBB", w, h, 8, 6, 0, 0, 0))
           + chunk(b"IDAT", zlib.compress(raw, 9)) + chunk(b"IEND", b""))
    open(path, "wb").write(png)


write_png(f"{TEX}/marlin_snail.png", SIZE, SIZE, buf)


# ---------------- java layer code ----------------
def f(v):
    return ("%g" % v) + "F"


lines = []
for p in parts:
    pv = "root" if p["parent"] == "root" else p["parent"]
    if p["box"]:
        x0, y0, z0, w, h, d = p["box"]
        u, v = p["uv"]
        cube = f"CubeListBuilder.create().texOffs({u}, {v}).addBox({f(x0)}, {f(y0)}, {f(z0)}, {f(w)}, {f(h)}, {f(d)})"
    else:
        cube = "CubeListBuilder.create()"
    ox, oy, oz, rx, ry, rz = p["pose"]
    if rx == ry == rz == 0 and ox == oy == oz == 0:
        pose = "PartPose.ZERO"
    elif rx == ry == rz == 0:
        pose = f"PartPose.offset({f(ox)}, {f(oy)}, {f(oz)})"
    else:
        pose = f"PartPose.offsetAndRotation({f(ox)}, {f(oy)}, {f(oz)}, {f(rx)}, {f(ry)}, {f(rz)})"
    lines.append(f'        PartDefinition {p["name"]} = {pv}.addOrReplaceChild("{p["name"]}", {cube}, {pose});')
layer_code = "\n".join(lines)

TEMPLATE = open("/home/claude/MarlinSnailModel.java.tpl", encoding="utf-8").read()
open(f"{JAVA}/MarlinSnailModel.java", "w", encoding="utf-8").write(TEMPLATE.replace("//LAYER//", layer_code).replace("//SIZE//", str(SIZE)))
print("parts:", len(parts), "boxes:", len(boxed), "atlas rows used up to y =", y + rowh)
