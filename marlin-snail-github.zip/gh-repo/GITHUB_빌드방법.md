# GitHub 에서 jar 자동 빌드하기

1. https://github.com/new 에서 새 저장소(Repository)를 만든다. (Public/Private 아무거나)
2. https://files.minecraftforge.net 에서 최신 26.x 의 **Mdk** 를 받아 압축을 푼다.
3. Mdk 폴더 안의 파일 중 **`src` 폴더만 빼고 전부**(gradlew, gradlew.bat, gradle 폴더, build.gradle,
   settings.gradle, gradle.properties 등)를 이 폴더(이 문서가 있는 곳)에 복사한다.
4. `gradle.properties` 안의 `mod_id` 를 `marlinsnail` 로 바꾼다.
5. 이 폴더의 모든 파일(`.github` 폴더 포함)을 새 저장소에 업로드한다.
   (웹에서 Add file > Upload files 로 끌어다 놓기. `.github` 가 안 올라가면 폴더째 올리기)
6. 저장소 위쪽 **Actions** 탭 > "Build mod jar" 를 열고 초록 체크가 뜰 때까지 기다린다.
7. 완료된 실행 화면 맨 아래 **Artifacts** 의 `marlin-snail-jar` 를 받는다. 압축을 풀면 jar 가 들어 있다.
8. jar 를 `.minecraft/mods` 에 넣는다.

빨간 X 가 뜨면 Actions 실행 화면의 빌드 로그 오류 부분을 복사해서 보내주세요.
